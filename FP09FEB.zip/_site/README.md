# fingerprinting-census
A Census about the adoption of Fingerprinting by Websites

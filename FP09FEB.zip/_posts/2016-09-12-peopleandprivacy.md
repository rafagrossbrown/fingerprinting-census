---
layout: default
title: “Oh … but people don’t care about privacy”
blurb: ""
date:   2016-09-12 12:17:05 +0100
categories: Blog
type: blog
author: "Nikolaos Laoutaris"
---

<div class="post-container">
<h2>“Oh … but people don’t care about privacy”</h2> 

<div class="author">
{{ page.author }}
</div>

<div class="post-date">
{{ page.date | date_to_string }}
</div>



<div class="blurb">
This post was initially published in <a href="http://laoutaris.info/index.php/2016/09/11/oh-but-people-dont-care-about-privacy/">Nikolaos Laoutaris's personal website</a> on September 11,2016.
</div>

<div class="post-body">
<p>If only I had a penny for every time I’ve heard this aphorism!</p>

<p>True, most typology studies out there as well as our own experiences verify that currently most of us act like the kids that rush to the table and grab the candy in the classic delayed gratification <a href="http://jamesclear.com/delayed-gratification">marshmallow experiment</a>: convenience rules over our privacy concerns.</p>
<p><a href="http://laoutaris.info/index.php/2016/09/11/oh-but-people-dont-care-about-privacy/">Continue reading here. <i class="fa fa-external-link fa-1x" style="color:#424242;"></i></a> </p>

<p></p>
<!-- close post body -->
</div>
</div>
